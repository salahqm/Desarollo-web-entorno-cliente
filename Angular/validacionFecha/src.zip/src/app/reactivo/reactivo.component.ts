import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactivo',
  templateUrl: './reactivo.component.html',
  styleUrls: ['./reactivo.component.css']
})
export class ReactivoComponent {
  FRegistro!: FormGroup;
  fechaValida!: boolean;
  pwd!: boolean;

  constructor(private fb: FormBuilder) {
    this.FRegistro = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      cumple: ['', [Validators.required]],
      trabajo: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.pattern(/^[A-Z].{8}[0-9]$/)]],
      repeatPassword: ['', [Validators.required,]],
    }, { validators: this.passwordMatchValidator, Validators: this.validateFecha });
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const password = formGroup.get('password')!.value;
    const repeatPassword = formGroup.get('repeatPassword')!.value;
    if (password !== repeatPassword) {
      formGroup.get('repeatPassword')!.setErrors({ mismatch: true });
    } else {
      formGroup.get('repeatPassword')!.setErrors(null);
    }
    return formGroup.get('repeatPassword')!.errors;


  }

  validateFecha(formGroup: FormGroup) {
    const fecha = formGroup.get('cumple')!.value;
    const fechaActual = new Date();
    if (fecha < fechaActual) {
      formGroup.get('cumple')!.setErrors({ invalido: true });
    } else {
      formGroup.get('cumple')!.setErrors(null);
    }
    return formGroup.get('cumple')!.errors;

  }

  enviar() {
    if (this.FRegistro.valid) {
      console.log('ok:', this.FRegistro.value);
    }
  }
}
