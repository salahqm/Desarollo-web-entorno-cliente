window.addEventListener('load',()=>{


    const url ="getImagenes.json"

    const caja = document.getElementById('cajaX');

    fetch(url)
    .then(response => response.json()) 
    .then(datos => mostrarDatos(datos)) 
    .finally(() => console.log("biennnnnnnnn")) 
    .catch(error => console.log(error.data));

    function mostrarDatos(datos){

        datos.forEach(item => {
           
            const tr = document.createElement('tr');
            caja.appendChild(tr);
            const td = document.createElement('td')
            tr.appendChild(td);
            const img = document.createElement('img');
            img.src = item.imagen;s
            td.appendChild(img)

            
        });
    }

})